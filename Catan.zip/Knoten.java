public class Knoten
{
    Knoten next;
    int intInhalt;
    
    Knoten(int inhalt)
    {
        intInhalt = inhalt;
    }
}