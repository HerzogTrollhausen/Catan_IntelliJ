public class Nuz
{
    public static final String NAECHSTER_RAEUBER = "Setze zunächst den Räuber, indem du auf eine Zahl klickst.";
    public static final String NAECHSTER_DEFAULT = "Runde beenden";
    public static final String OK = "Ok";
    public static final String RAUB_NOTIFICATION_TITLE = "Raubzug";
    public static final String RAUB_ATTACKER_NOTIFICATION_MESSAGE_1 = "Du hast ein ";
    public static final String RAUB_ATTACKER_NOTIFICATION_MESSAGE_2 = " erhalten!";
    public static final String RAUB_DEFENDER_NOTIFICATION_MESSAGE_1 = "Dir wurde ein ";
    public static final String RAUB_DEFENDER_NOTIFICATION_MESSAGE_2 = "gestohlen!";
    public static final String HOLZ = "Holz";
    public static final String LEHM = "Lehm";
    public static final String SCHAF = "Schaf";
    public static final String WEIZEN = "Weizen";
    public static final String ERZ = "Erz";
    public static final String PLAYER_TRADE_AGREE = "Zustimmen";
    public static final String PLAYER_TRADE_REFUSE = "Ablehnen";
}
